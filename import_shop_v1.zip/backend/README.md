# Import Shop — Backend v1

## اجرا
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Swagger:
http://localhost:8000/docs

## API
POST /api/calculate
GET /api/quotes

این نسخه قیمت و وزن را از فرم می‌گیرد و محاسبه را در SQLite ذخیره می‌کند.
مرحله بعد: اتصال امن به منبع داده محصول (ترجیحاً API رسمی فروشگاه/سرویس مجاز)، سپس سفارش و پنل ادمین.
