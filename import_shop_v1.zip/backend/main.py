from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlparse
import os

from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl, Field
from sqlalchemy import create_engine, String, Numeric, Integer, DateTime, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./app.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)

class Base(DeclarativeBase):
    pass

class Quote(Base):
    __tablename__ = "quotes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    url: Mapped[str] = mapped_column(String(1000))
    store: Mapped[str] = mapped_column(String(100))
    product_price_usd: Mapped[Decimal] = mapped_column(Numeric(12,2))
    weight_kg: Mapped[Decimal] = mapped_column(Numeric(10,2))
    exchange_rate: Mapped[Decimal] = mapped_column(Numeric(14,2))
    total_irr: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[object] = mapped_column(DateTime, server_default=func.now())

Base.metadata.create_all(engine)

app = FastAPI(title="Import Shop API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"]
)

SERVICE_FEE_PERCENT = Decimal(os.getenv("SERVICE_FEE_PERCENT", "8"))
CUSTOMS_PERCENT = Decimal(os.getenv("CUSTOMS_PERCENT", "5"))
DEFAULT_RATE = Decimal(os.getenv("EXCHANGE_RATE", "120000"))
SHIPPING_PER_KG_USD = Decimal(os.getenv("SHIPPING_PER_KG_USD", "12"))

class CalculateRequest(BaseModel):
    url: HttpUrl
    product_price_usd: Decimal = Field(gt=0)
    weight_kg: Decimal = Field(default=Decimal("1"), gt=0)
    exchange_rate: Decimal = Field(default=DEFAULT_RATE, gt=0)

class CalculateResponse(BaseModel):
    quote_id: int
    store: str
    product_price_irr: int
    shipping_irr: int
    service_fee_irr: int
    customs_irr: int
    total_irr: int

def money(x: Decimal) -> int:
    return int(x.quantize(Decimal("1"), rounding=ROUND_HALF_UP))

def detect_store(url: str) -> str:
    host = urlparse(url).netloc.lower()
    host = host.removeprefix("www.")
    if "amazon.ae" in host: return "Amazon UAE"
    if "amazon.com" in host: return "Amazon US"
    if "amazon.co.uk" in host: return "Amazon UK"
    return host or "Unknown"

def db():
    s = SessionLocal()
    try:
        yield s
    finally:
        s.close()

@app.get("/api/health")
def health():
    return {"ok": True, "version": "1.0.0"}

@app.post("/api/calculate", response_model=CalculateResponse)
def calculate(body: CalculateRequest, session: Session = Depends(db)):
    price = body.product_price_usd
    shipping = body.weight_kg * SHIPPING_PER_KG_USD
    service = (price + shipping) * SERVICE_FEE_PERCENT / 100
    customs = price * CUSTOMS_PERCENT / 100
    total = price + shipping + service + customs

    q = Quote(
        url=str(body.url), store=detect_store(str(body.url)),
        product_price_usd=price, weight_kg=body.weight_kg,
        exchange_rate=body.exchange_rate, total_irr=money(total * body.exchange_rate)
    )
    session.add(q)
    session.commit()
    session.refresh(q)

    return CalculateResponse(
        quote_id=q.id, store=q.store,
        product_price_irr=money(price * body.exchange_rate),
        shipping_irr=money(shipping * body.exchange_rate),
        service_fee_irr=money(service * body.exchange_rate),
        customs_irr=money(customs * body.exchange_rate),
        total_irr=money(total * body.exchange_rate),
    )

@app.get("/api/quotes")
def quotes(session: Session = Depends(db)):
    rows = session.query(Quote).order_by(Quote.id.desc()).limit(50).all()
    return [{
        "id": q.id, "store": q.store, "url": q.url,
        "product_price_usd": float(q.product_price_usd),
        "weight_kg": float(q.weight_kg),
        "exchange_rate": float(q.exchange_rate),
        "total_irr": q.total_irr,
        "created_at": q.created_at.isoformat() if q.created_at else None
    } for q in rows]
